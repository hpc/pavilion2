import subprocess
import pavilion.system_variables as system_plugins

class SystemArch(system_plugins.SystemPlugin):

    def __init__(self):
        super().__init__(
            name='sys_arch',
            description="The LANL HPC system architecture.",
            priority=20,
            is_deferable=False,
            sub_keys=None)

    def _get(self):
        """Base method for determining the system architecture."""

        arch = subprocess.check_output([
            '/usr/projects/hpcsoft/utilities/bin/sys_arch'])
        return arch.strip().decode('utf8')
